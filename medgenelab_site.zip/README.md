# Bahareh Genetics Lab Website
این مخزن مربوط به سایت رسمی آزمایشگاه ژنتیک پزشکی بهاره است.